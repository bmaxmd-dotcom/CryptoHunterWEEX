package com.max.cryptohunter

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.text.DecimalFormat
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MonitorService:Service(){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private val alerted=ConcurrentHashMap<String,Boolean>()
    private var loop:Job?=null
    override fun onCreate(){super.onCreate(); createChannel()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        startForeground(77,notification("Monitorizare WEEX activă"))
        when(intent?.action){"STOP"->{stopSelf();return START_NOT_STICKY};"SCAN_NOW"->scope.launch{autoScan(true)};else->startLoop()}
        return START_STICKY
    }
    private fun startLoop(){if(loop?.isActive==true)return; loop=scope.launch{
        var lastAuto=0L
        while(isActive){ manualCheck(); val now=System.currentTimeMillis(); if(Prefs.auto(this@MonitorService)&&now-lastAuto>15*60_000){autoScan(false);lastAuto=now}; delay(5000) }
    }}
    private suspend fun manualCheck(){
        Prefs.rules(this).filter{it.enabled&&it.symbol.isNotBlank()}.map{r->scope.async{ val m=WeexApi.candle(r.symbol)?:return@async; checkRule(m,r) }}.awaitAll()
    }
    private suspend fun checkRule(m:CandleMove,r:CoinRule){
        val direction=when{m.pct>=r.pump->"PUMP";m.pct<=-r.dump->"DUMP";else->return}
        val key="${m.symbol}:${m.startTime}:$direction"; if(alerted.putIfAbsent(key,true)!=null)return
        val icon=if(direction=="PUMP")"🚀" else "🔻"; val msg="$icon ALERTĂ $direction\n\nMonedă: ${m.symbol}\nTimeframe: 15m\nSchimbare: ${fmt(m.pct)}%\nOpen: ${m.open}\nPreț actual: ${m.last}"
        WeexApi.telegram(Prefs.token(this),Prefs.chat(this),msg); notifyLocal(msg)
        if(alerted.size>1000) alerted.clear()
    }
    private suspend fun autoScan(force:Boolean){
        val syms=WeexApi.symbols(); if(syms.isEmpty()){if(force)WeexApi.telegram(Prefs.token(this),Prefs.chat(this),"⚠️ AUTO SCAN: nu am putut încărca perechile WEEX");return}
        val sem=Semaphore(8); val moves=syms.take(500).map{s->scope.async{sem.withPermit{delay(35);WeexApi.candle(s)}}}.awaitAll().filterNotNull()
        val pumps=moves.filter{it.pct>=Prefs.autoPump(this)}.sortedByDescending{it.pct}.take(10)
        val dumps=moves.filter{it.pct<=-Prefs.autoDump(this)}.sortedBy{it.pct}.take(10)
        if(pumps.isEmpty()&&dumps.isEmpty()){if(force)WeexApi.telegram(Prefs.token(this),Prefs.chat(this),"AUTO SCAN 15m: nicio mișcare peste pragurile setate.");return}
        val text=buildString{append("🔥 AUTO SCAN WEEX — 15m\n\n");append("TOP PUMP\n");pumps.forEachIndexed{i,m->append("${i+1}. ${m.symbol} ${fmt(m.pct)}%\n")};append("\nTOP DUMP\n");dumps.forEachIndexed{i,m->append("${i+1}. ${m.symbol} ${fmt(m.pct)}%\n")}}
        val bucket=System.currentTimeMillis()/(15*60_000); val signature=(pumps+dumps).joinToString{"${it.symbol}:${fmt(it.pct)}"}; val key="auto:$bucket:$signature"; if(alerted.putIfAbsent(key,true)==null){WeexApi.telegram(Prefs.token(this),Prefs.chat(this),text);notifyLocal(text)}
    }
    private fun fmt(v:Double)=DecimalFormat("+0.00;-0.00").format(v)
    private fun createChannel(){val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("monitor","Monitorizare WEEX",NotificationManager.IMPORTANCE_LOW));nm.createNotificationChannel(NotificationChannel("alerts","Alerte crypto",NotificationManager.IMPORTANCE_HIGH))}
    private fun notification(t:String)=NotificationCompat.Builder(this,"monitor").setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("Crypto Hunter WEEX").setContentText(t).setOngoing(true).build()
    private fun notifyLocal(t:String){getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),NotificationCompat.Builder(this,"alerts").setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("Crypto Hunter WEEX").setStyle(NotificationCompat.BigTextStyle().bigText(t)).setAutoCancel(true).build())}
    override fun onDestroy(){scope.cancel();super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
