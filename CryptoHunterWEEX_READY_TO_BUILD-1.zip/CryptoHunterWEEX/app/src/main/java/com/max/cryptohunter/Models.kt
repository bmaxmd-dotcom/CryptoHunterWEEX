package com.max.cryptohunter

data class CoinRule(val enabled:Boolean, val symbol:String, val pump:Double, val dump:Double)
data class CandleMove(val symbol:String, val open:Double, val last:Double, val startTime:Long) {
    val pct: Double get() = if (open == 0.0) 0.0 else (last-open)/open*100.0
}
