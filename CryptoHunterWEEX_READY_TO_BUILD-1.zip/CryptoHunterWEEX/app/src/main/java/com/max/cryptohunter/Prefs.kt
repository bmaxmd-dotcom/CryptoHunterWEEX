package com.max.cryptohunter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private const val NAME="crypto_hunter"
    fun save(context:Context, token:String, chat:String, auto:Boolean, autoPump:Double, autoDump:Double, rules:List<CoinRule>) {
        val arr=JSONArray()
        rules.forEach { arr.put(JSONObject().put("enabled",it.enabled).put("symbol",it.symbol).put("pump",it.pump).put("dump",it.dump)) }
        context.getSharedPreferences(NAME,Context.MODE_PRIVATE).edit()
            .putString("token",token).putString("chat",chat).putBoolean("auto",auto)
            .putFloat("autoPump",autoPump.toFloat()).putFloat("autoDump",autoDump.toFloat())
            .putString("rules",arr.toString()).apply()
    }
    fun token(c:Context)=c.getSharedPreferences(NAME,Context.MODE_PRIVATE).getString("token","") ?: ""
    fun chat(c:Context)=c.getSharedPreferences(NAME,Context.MODE_PRIVATE).getString("chat","") ?: ""
    fun auto(c:Context)=c.getSharedPreferences(NAME,Context.MODE_PRIVATE).getBoolean("auto",false)
    fun autoPump(c:Context)=c.getSharedPreferences(NAME,Context.MODE_PRIVATE).getFloat("autoPump",5f).toDouble()
    fun autoDump(c:Context)=c.getSharedPreferences(NAME,Context.MODE_PRIVATE).getFloat("autoDump",5f).toDouble()
    fun rules(c:Context):List<CoinRule>{
        val raw=c.getSharedPreferences(NAME,Context.MODE_PRIVATE).getString("rules","[]") ?: "[]"
        val arr=JSONArray(raw); return (0 until arr.length()).map { i ->
            val o=arr.getJSONObject(i); CoinRule(o.optBoolean("enabled",true),o.optString("symbol"),o.optDouble("pump",5.0),o.optDouble("dump",5.0))
        }
    }
}
