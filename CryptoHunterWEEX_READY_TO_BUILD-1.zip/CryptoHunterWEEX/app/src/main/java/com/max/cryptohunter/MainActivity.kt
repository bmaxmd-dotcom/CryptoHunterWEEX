package com.max.cryptohunter

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity:AppCompatActivity(){
    private data class Row(val root:android.view.View,val enabled:CheckBox,val symbol:EditText,val pump:EditText,val dump:EditText)
    private val rows=mutableListOf<Row>()
    private val notificationPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_main)
        if(Build.VERSION.SDK_INT>=33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val container=findViewById<LinearLayout>(R.id.coinRows)
        val defaults=listOf("BTCUSDT","ETHUSDT","BANKUSDT","COTIUSDT","SOONUSDT","EULUSDT")
        val saved=Prefs.rules(this)
        repeat(6){i-> val v=LayoutInflater.from(this).inflate(R.layout.row_coin,container,false); container.addView(v)
            val row=Row(v,v.findViewById(R.id.enabled),v.findViewById(R.id.symbol),v.findViewById(R.id.pump),v.findViewById(R.id.dump)); rows+=row
            val s=saved.getOrNull(i); row.enabled.isChecked=s?.enabled?:true; row.symbol.setText(s?.symbol?:defaults[i]); row.pump.setText((s?.pump?:5.0).toString()); row.dump.setText((s?.dump?:5.0).toString()) }
        findViewById<EditText>(R.id.tokenInput).setText(Prefs.token(this)); findViewById<EditText>(R.id.chatInput).setText(Prefs.chat(this))
        findViewById<CheckBox>(R.id.autoScanCheck).isChecked=Prefs.auto(this); findViewById<EditText>(R.id.autoPumpInput).setText(Prefs.autoPump(this).toString()); findViewById<EditText>(R.id.autoDumpInput).setText(Prefs.autoDump(this).toString())
        findViewById<Button>(R.id.startButton).setOnClickListener{save(); ContextCompat.startForegroundService(this,Intent(this,MonitorService::class.java).setAction("START")); findViewById<TextView>(R.id.statusText).text="Monitorizare activă"}
        findViewById<Button>(R.id.stopButton).setOnClickListener{startService(Intent(this,MonitorService::class.java).setAction("STOP")); findViewById<TextView>(R.id.statusText).text="Monitorizare oprită"}
        findViewById<Button>(R.id.testButton).setOnClickListener{save(); lifecycleScope.launch{ val ok=WeexApi.telegram(Prefs.token(this@MainActivity),Prefs.chat(this@MainActivity),"✅ Crypto Hunter WEEX: test Telegram reușit"); Toast.makeText(this@MainActivity,if(ok)"Trimis" else "Eroare",Toast.LENGTH_LONG).show() }}
        findViewById<Button>(R.id.scanNowButton).setOnClickListener{save(); ContextCompat.startForegroundService(this,Intent(this,MonitorService::class.java).setAction("SCAN_NOW")); Toast.makeText(this,"Scanarea a pornit",Toast.LENGTH_SHORT).show()}
    }
    private fun d(e:EditText,def:Double)=e.text.toString().toDoubleOrNull()?.coerceIn(0.1,50.0)?:def
    private fun save(){ val rules=rows.map{CoinRule(it.enabled.isChecked,it.symbol.text.toString().trim().uppercase(),d(it.pump,5.0),d(it.dump,5.0))}; Prefs.save(this,findViewById<EditText>(R.id.tokenInput).text.toString().trim(),findViewById<EditText>(R.id.chatInput).text.toString().trim(),findViewById<CheckBox>(R.id.autoScanCheck).isChecked,d(findViewById(R.id.autoPumpInput),5.0),d(findViewById(R.id.autoDumpInput),5.0),rules)}
}
