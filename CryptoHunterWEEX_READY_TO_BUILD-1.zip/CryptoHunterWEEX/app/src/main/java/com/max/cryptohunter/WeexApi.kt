package com.max.cryptohunter

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.FormBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object WeexApi {
    private val client=OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).build()
    suspend fun candle(symbol:String):CandleMove?=withContext(Dispatchers.IO){
        val url="https://api-contract.weex.com/capi/v2/market/candles?symbol=${symbol.uppercase()}&granularity=15m&limit=1&priceType=LAST"
        val text=client.newCall(Request.Builder().url(url).build()).execute().use { if(!it.isSuccessful) return@withContext null; it.body?.string() ?: return@withContext null }
        parseCandle(symbol,text)
    }
    private fun parseCandle(symbol:String,text:String):CandleMove? {
        val root=runCatching { JSONObject(text) }.getOrNull()
        val data:Any?=root?.opt("data") ?: runCatching { JSONArray(text) }.getOrNull()
        val row:Any?=when(data){ is JSONArray -> if(data.length()>0)data.get(data.length()-1) else null; else -> null }
        if(row is JSONArray && row.length()>=5){
            val t=row.optString(0).toLongOrNull() ?: System.currentTimeMillis(); val o=row.optString(1).toDoubleOrNull() ?: return null; val c=row.optString(4).toDoubleOrNull() ?: return null
            return CandleMove(symbol.uppercase(),o,c,t)
        }
        if(row is JSONObject){
            val t=row.optLong("timestamp",row.optLong("time",System.currentTimeMillis())); val o=row.optString("open").toDoubleOrNull() ?: return null; val c=(row.optString("close").ifBlank{row.optString("last")}).toDoubleOrNull() ?: return null
            return CandleMove(symbol.uppercase(),o,c,t)
        }
        return null
    }
    suspend fun symbols():List<String>=withContext(Dispatchers.IO){
        val url="https://api-contract.weex.com/capi/v3/market/exchangeInfo"
        val text=client.newCall(Request.Builder().url(url).build()).execute().use { if(!it.isSuccessful) return@withContext emptyList(); it.body?.string() ?: return@withContext emptyList() }
        val direct=runCatching{JSONArray(text)}.getOrNull(); if(direct!=null) return@withContext (0 until direct.length()).map{direct.optString(it)}.filter{it.endsWith("USDT")}
        val obj=runCatching{JSONObject(text)}.getOrNull() ?: return@withContext emptyList()
        val arr=obj.optJSONArray("symbols") ?: obj.optJSONObject("data")?.optJSONArray("symbols") ?: obj.optJSONArray("data") ?: return@withContext emptyList()
        (0 until arr.length()).mapNotNull { i ->
            when(val item=arr.opt(i)) {
                is JSONObject -> item.optString("symbol").takeIf { it.endsWith("USDT") }
                is String -> item.takeIf { it.endsWith("USDT") }
                else -> null
            }
        }
    }
    suspend fun telegram(token:String,chat:String,message:String):Boolean=withContext(Dispatchers.IO){
        if(token.isBlank()||chat.isBlank()) return@withContext false
        val body=FormBody.Builder().add("chat_id",chat).add("text",message).build()
        runCatching { client.newCall(Request.Builder().url("https://api.telegram.org/bot$token/sendMessage").post(body).build()).execute().use{it.isSuccessful} }.getOrDefault(false)
    }
}
