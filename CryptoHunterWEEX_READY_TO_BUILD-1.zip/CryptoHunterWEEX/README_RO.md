# Crypto Hunter WEEX — Android 1.0

Funcții incluse:
- monitorizare manuală pentru maximum 6 perechi;
- prag PUMP și prag DUMP separat, 0.1%–50%, pentru fiecare monedă;
- timeframe 15m;
- Telegram și notificări Android;
- serviciu foreground pentru lucru în fundal;
- AUTO SCAN pentru până la 500 de perechi WEEX;
- SCAN NOW;
- top 10 pump și top 10 dump peste pragurile setate;
- evitarea alertelor duplicate în aceeași lumânare.

## Compilare APK
1. Instalează Android Studio pe Windows/Mac.
2. Deschide folderul `CryptoHunterWEEX`.
3. Așteaptă Gradle Sync.
4. Build > Build APK(s).
5. APK-ul va fi în `app/build/outputs/apk/debug/app-debug.apk`.

## Telegram
1. Creează un bot cu @BotFather și copiază tokenul.
2. Trimite un mesaj botului.
3. Deschide în browser `https://api.telegram.org/botTOKEN/getUpdates` și copiază `chat.id`.
4. Introdu tokenul și Chat ID în aplicație, apoi apasă TEST TELEGRAM.

## Observații
- Dezactivează optimizarea bateriei pentru aplicație.
- AUTO SCAN folosește endpointurile publice WEEX; nu cere API key și nu deschide tranzacții.
- Prima scanare completă poate dura câteva minute, în funcție de numărul de perechi și internet.
- Structura răspunsului API se poate schimba; proiectul are parser pentru formatele comune array/object.

## Compilare automată fără Android Studio
Proiectul include `.github/workflows/build-apk.yml`. După încărcarea proiectului într-un repository GitHub, deschide Actions → Build Android APK → Run workflow. APK-ul apare la Artifacts cu numele `CryptoHunterWEEX-debug-apk`.
